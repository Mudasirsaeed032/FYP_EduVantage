import React, { useState } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import './UserProfile.css'

const UserProfile = () => {
    // State to store the selected test and score
    const [selectedTest, setSelectedTest] = useState("");
    const [scoreRange, setScoreRange] = useState({ min: 0, max: 120 });

    // State to track current step in the form
    const [step, setStep] = useState(1);

    // Handle test selection
    const handleTestChange = (e) => {
        const test = e.target.value;
        setSelectedTest(test);

        // Set score range based on the selected test
        switch (test) {
            case "IELTS":
                setScoreRange({ min: 0, max: 9 });
                break;
            case "TOEFL":
                setScoreRange({ min: 0, max: 120 });
                break;
            case "PTE":
                setScoreRange({ min: 10, max: 90 });
                break;
            case "Duolingo":
                setScoreRange({ min: 10, max: 160 });
                break;
            case "Cambridge":
                setScoreRange({ min: 0, max: 230 });
                break;
            case "TOEIC":
                setScoreRange({ min: 10, max: 990 });
                break;
            default:
                setScoreRange({ min: 0, max: 120 });
                break;
        }
    };

    return (
        <div className="section1" id="user_section1">
            <div className="container-fluid" id="user_container">
                <header id="user_header">User Profile</header>
                <form>
                    {/* Step 1: Personal Information and Academic Details */}
                    {step === 1 && (
                        <div className="form first">
                            <div className="details personal">
                                <span className="title">Personal Information</span>

                                <div className="fields" id="user_fields">
                                    <div className="input-field" id="user_input_field">
                                        <label htmlFor="fullName">Full Name</label>
                                        <input id="fullName" type="text" placeholder="Enter your name" required />
                                    </div>

                                    <div className="input-field" id="user_input_field">
                                        <label htmlFor="dob">Date of Birth</label>
                                        <input id="dob" type="date" placeholder="Enter birth date" required />
                                    </div>

                                    <div className="input-field" id="user_input_field">
                                        <label htmlFor="email">Email</label>
                                        <input id="email" type="email" placeholder="Enter your email" required />
                                    </div>

                                    <div className="input-field" id="user_input_field">
                                        <label htmlFor="mobileNumber">Mobile Number</label>
                                        <input id="mobileNumber" type="tel" placeholder="Enter mobile number" required />
                                    </div>

                                    <div className="input-field" id="user_input_field">
                                        <label htmlFor="gender">Gender</label>
                                        <select id="gender" defaultValue="" required>
                                            <option value="" disabled>
                                                Select gender
                                            </option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                            <option value="Others">Others</option>
                                        </select>
                                    </div>

                                    <div className="input-field" id="user_input_field">
                                        <label htmlFor="country">Country of Residence</label>
                                        <input id="country" type="text" placeholder="Enter your occupation" required />
                                    </div>
                                </div>
                            </div>

                            {/* Academic Details Section */}
                            <div className="details ID">
                                <span className="title">Academic Details</span>

                                <div className="fields">
                                    <div className="input-field" id="user_input_field">
                                        <label htmlFor="gpaType">GPA Type</label>
                                        <input id="gpaType" type="text" placeholder="Enter GPA Type" required />
                                    </div>

                                    <div className="input-field" id="user_input_field">
                                        <label htmlFor="gpaNumber">GPA Number</label>
                                        <input id="gpaNumber" type="number" placeholder="Enter GPA" required />
                                    </div>

                                    <div className="input-field" id="user_input_field">
                                        <label htmlFor="fieldOfBachelors">Field of Bachelors</label>
                                        <input id="fieldOfBachelors" type="text" placeholder="Enter your Field of Bachelors" required />
                                    </div>

                                    <div className="input-field" id="user_input_field">
                                        <label htmlFor="institution">Previous/Current Institution</label>
                                        <input id="institution" type="text" placeholder="Previous/Current Institution" required />
                                    </div>

                                    <div className="input-field" id="user_input_field">
                                        <label htmlFor="workExperience">Work Experience</label>
                                        <input id="workExperience" type="number" placeholder="Enter your Work Experience" required />
                                    </div>
                                </div>

                                <div className="Test Scores Detail">
                                    <span className="title">Test Scores Detail</span>

                                    <div className="fields">
                                        <div className="input-field" id="user_input_field">
                                            <label htmlFor="testType">Which Language test(s) have you given?</label>
                                            <select id="testType" required defaultValue="" onChange={handleTestChange}>
                                                <option value="" disabled>
                                                    Select your test
                                                </option>
                                                <option value="TOEFL">TOEFL</option>
                                                <option value="IELTS">IELTS</option>
                                                <option value="PTE">PTE</option>
                                                <option value="Duolingo">Duolingo</option>
                                                <option value="Cambridge">Cambridge English Exam</option>
                                                <option value="TOEIC">TOEIC</option>
                                            </select>
                                        </div>

                                        <div className="input-field" id="user_input_field">
                                            <label htmlFor="testScore">Test Score</label>
                                            <input
                                                id="testScore"
                                                type="number"
                                                placeholder={`Enter your ${selectedTest} score`}
                                                min={scoreRange.min}
                                                max={scoreRange.max}
                                                required
                                            />
                                            <small>{`Score should be between ${scoreRange.min} and ${scoreRange.max}`}</small>
                                        </div>
                                    </div>
                                </div>

                                <div className="Test Scores Detail">
                                    <span className="title">Budget Details</span>
                                    <div className="fields">
                                        <div className="input-field" id="user_input_field">
                                            <label htmlFor="tuitionBudget">Tuition Budget (USD)</label>
                                            <input
                                                id="tuitionBudget"
                                                type="number"
                                                placeholder="Enter your tuition budget in USD"
                                                required
                                            />
                                        </div>

                                        <div className="input-field" id="user_input_field">
                                            <label htmlFor="livingAllowance">Monthly Living Allowance (USD)</label>
                                            <input
                                                id="livingAllowance"
                                                type="number"
                                                placeholder="Enter your monthly living allowance in USD"
                                                required
                                            />
                                        </div>
                                    </div>
                                </div>

                                <button id="submitButton" type="submit">Submit</button>
                            </div>
                        </div>
                    )}
                </form>
            </div>
        </div>
    );
};

export default UserProfile;
