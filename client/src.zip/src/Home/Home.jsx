import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for navigation
import Navbar from '../Boilerplate/Navbar';
import Footer from '../Boilerplate/Footer';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import './Home.css';

export default function Home() {
    const [searchQuery, setSearchQuery] = useState('');
    const [user, setUser] = useState(null);
    const [isLoading, setIsLoading] = useState(true);

    const navigate = useNavigate();


    axios.default.withCredentials = true;
    useEffect(() => {
        axios.get('http://localhost:3000/home', { withCredentials: true })
            .then((res) => {
                console.log(res.data);
                if (res.data.user) {
                    setUser(res.data.user);
                    console.log(res.data.user);
                } else {
                    setUser(null);
                    console.log(res.data.message || "An unexpected error occurred.");
                }
                setIsLoading(false);  // Set loading to false after fetching
            })
            .catch((err) => {
                console.error('error:', err);
                alert('Failed to fetch user data.');
                setUser(null);
                setIsLoading(false);  // Set loading to false after fetching
            })
    }, []);

    const handleLogout = () => {
        axios.get('http://localhost:3000/logout', { withCredentials: true })
            .then((res) => {
                console.log(res.data.message);
                setUser(null);
                navigate('/home');
            })
            .catch((err) => {
                console.error('error:', err);
            });
    }

    const handleQuickResults = () => {
        if (searchQuery.trim()) {
            console.log('Quick Results for:', searchQuery);
            // Navigate to the recommendation page for quick results
            navigate('/recommendation');
        } else {
            alert('Please enter a search query.');
        }
    };

    const handleComprehensiveScan = () => {
        if (searchQuery.trim()) {
            console.log('Comprehensive Scan for:', searchQuery);
            // Navigate to the recommendation page for comprehensive scan
            navigate('/recommendation');
        } else {
            alert('Please enter a search query.');
        }
    };
    if (isLoading) {
        return <div className="text-center">
            <div className="spinner-border" role="status">
                <span className="sr-only">Loading...</span>
            </div>
        </div>;
    }

    return (
        <div>
            <Navbar user={user} handleLogout={handleLogout} />
            <main className='home container-fluid p-0'>
                <section className='section mt-5' id='section1'>
                    <div className='row'>
                        <div className='col-2'></div>
                        <div className='col-8 fade-in' id="mainTagline">
                            Welcome to <span className='highlightedWord'> EduVantage  </span>
                        </div>
                        <div className='col-2'></div>
                    </div>

                    <div className="row justify-content-center">
                        {/* Wrap the input and buttons together in one flex container */}
                        <div className="col-sm-8 d-flex search-bar-wrapper">
                            <input
                                type="text"
                                className="search-input"
                                placeholder="Prompt your preferences (region, program, etc.)"
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                            />
                            <button className="quick-results-btn" onClick={handleQuickResults}>
                                Show Quick Results
                            </button>
                            <button className="comprehensive-scan-btn" onClick={handleComprehensiveScan}>
                                Comprehensive Scan
                            </button>
                        </div>
                    </div>
                </section>

                <div><Footer /></div>
            </main>
        </div>
    );
}
